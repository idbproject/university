<h3>Input Sizing</h3>
<form role="form">
<div class="form-group">
  <label for="inputdefault">Default input</label>
  <input class="form-control" id="inputdefault" type="text">
</div>
<div class="form-group">
  <label for="inputlg">input-lg</label>
  <input class="form-control input-lg" id="inputlg" type="text">
</div>
<div class="form-group">
  <label for="inputsm">input-sm</label>
  <input class="form-control input-sm" id="inputsm" type="text">
</div>
<div class="form-group">
  <label for="sel1">Default select list</label>
  <select class="form-control" id="sel1">
    <option>1</option>
  </select>
</div>
<div class="form-group">
  <label for="sel2">input-lg</label>
  <select class="form-control input-lg" id="sel2">
    <option>1</option>
   </select>
</div>
<div class="form-group">
  <label for="sel3">input-sm</label>
  <select class="form-control input-sm" id="sel3">
    <option>1</option>
  </select>
</div>
</form>