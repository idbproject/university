<!doctype html>
<html ng-app="defaultApp">
<head>
<meta charset="utf-8">
<title>Home</title>
	<script src="js/angular.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.css" rel="stylesheet" />
    <link href="css/icon.css" rel="stylesheet"/>
    <link href="css/style.css" rel="stylesheet"/>
    <link href="css/font-awesome.min.css" rel="stylesheet"/>
 <script>
	var app = angular.module("defaultApp", ['arrivialApp']);
$(document).ready(function(){
    $("ul").click(function(){
        $(".menuDdown").animate({
            left: '70px',
            opacity: '1',
            width: '700px'
        });
    });
});
</script>
</head>

<body>
<!-- Menue =================================================================================-->
<div class="control-label">
	<div class="row">
   	 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">                    	
                <a href="#" class="navbar-brand">Menu</a>
                 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#ourMenu">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="ourMenu">
              <ul class="nav navbar-nav">
                <li><a href="#/dashboard" ng-click="page_change('views/home.php')">Home</a></li>
                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/arrival_massare.php')">Arrival Massage</a></li>
                <li ng-show="ourmenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Settings <span class="caret"></span></a>
                  <ul ng-show="ourmenu" class="dropdown-menu menuDdown">
                  	<table border="1" bordercolor="#FFFFFF"cellspacing="10" cellpadding="10">
                    	<tr>
                        	<td>
                                <li class="modal-body"><h4 class="menuColor">Settings Menu</h4></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/airlines.php')">Airlines</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/airport.php')">Airport</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/rute.php')">Rute</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/flight.php')">Flight</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/terminal.php')">Terminal</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/gate.php')">Gate</a></li>
                                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/details.php')">Details</a></li>       
                            </td>
                            <td></td>
                        </tr>
                    </table>
                                                 
                  </ul>
                </li>
                <li ng-show="ourmenu"><a href="#" ng-click="page_change('views/register.php')">Register</a></li>
                <li ng-show="ourmenu"><a href="#/login">Login</a></li>
                <li ng-show="ourmenu"><a href="#/logout" ng-click="logout()">Logout</a></li>
                <li ng-show="ourmenu"><a href="#/change-password" ng-click="logout()">Change Password</a></li>
              </ul>
              <form class="navbar-form navbar-right">
                    <div class="form-group">
                        <input type="text" class="form-control"/>
                        <button type="button" class="btn btn-success">Search</button>
                    </div>
              </form>
            </div>    
        </div>
      </nav>             
    </div>            
    </div>	
</div>
<!-- ====Body =============================================================-->
<div ng-view></div>
<!-- Footer =============================================================== -->
<div class="container-fluid">
	<div class="row panel-footer table-bordered">
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>Communication</h4></label>
                <li>Address</li>
                <li>Contact</li>
                <li>Chat</li>
                <li>University Location</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Information</h4></label>
                <li>History</li>
                <li>Governance</li>
                <li>University Officer</li>
                <li>Faculty Member</li>
                <li>Strategic Plan</li>
                <li>Financing and funding</li>
            </ul>
        </div>
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>Academic Review</h4></label>
                <li>Annual Review</li>
                <li>Mejor success</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Educational Review</h4></label>
                <li>Faculty</li>
                <li>Course Fee</li>
                <li>Credit and fees</li>
                <li>Course and Semister</li>
                <li>Course and Syllabus</li>
                <li>Subject</li>
            </ul>
        </div>
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>IDB Facility</h4></label>
                <li>International Community</li>
                <li>Credit Transfer</li>
                <li>Library</li>
                <li>Schollarship</li>
                <li>Welfare and counselling</li>
                <li>Award</li>
                <li>Hostel</li>
                <li>International Community</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Studing at IDB University</h4></label>
                <li>Gradguate Admission</li>
                <li>Master's Admission</li>
                <li>MBA Admission</li>
                <li>Phd</li>
            </ul>
        </div>
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>Admission Notice</h4></label>
                <li>Admission Circular</li>
                <li>Apply</li>
                <li>Exam Schedule</li>
                <li>Result</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Notice for..</h4></label>
                <li>Open</li>
                <li>Staff</li>
                <li>Faculty</li>
                <li>Student</li>
                <li>Guardian</li>
            </ul>
        </div>
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>Access/login</h4></label>
                <li>Directory</li>
                <li>Staff</li>
                <li>Faculty Member</li>
                <li>Student</li>
                <li>Guardian</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Careers</h4></label>
                <li>Job Circular</li>
                <li>Apply</li>
                <li>Our Ergonomics</li>
                <li>Ergonomics Environment</li>
            </ul>
        </div>
        <div class="col-sm-2">
            <ul>
                <label class="menuColor"><h4>Sports & Culture</h4></label>
                <li>Club</li>
                <li>Events</li>
                <li>Society</li>
                <li>Culture</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>University Accounts</h4></label>
                <li>Financial Accounts</li>
                <li>Financial Report</li>
                <li>Petty cash</li>
                <li>Cash Account</li>
                <li>Student Fees</li>
            </ul>
            <ul>
                <label class="menuColor"><h4>Student Management</h4></label>
                <li>Attendece Count</li>
                <li>Study Plan</li>
                <li>Create Result</li>
            </ul>
        </div>
    </div>
    <div class="row panel panel-default panel-body myfooter">
    	<div class="col-sm-4"></div>
        <div class="col-sm-4"></div>
        <div class="col-sm-4"></i></div>
    </div>
</div>
</body>
</html>
