<!DOCTYPE html>
<html ng-app="exampleApp">
<head>
 <title>About</title>
	<script src="js/angular.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet"/>
</head>
<body>
<div class="container-fluid">
	<div class="row">
    	<div class="col-sm-12">
        	<div class="row menuBeg">
            	<div class="col-sm-2">
                	<ul>
                    	<li><h4>Admission Notice</h4></li>
                        <li>Admission Circular</li>
                        <li>Apply</li>
                        <li>Exam Schedule</li>
                        <li>Result</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Notice for..</h4></li>
                        <li>Open</li>
                        <li>Staff</li>
                        <li>Faculty</li>
                        <li>Student</li>
                        <li>Guardian</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Access/login</h4></li>
                        <li>Directory</li>
                        <li>Staff</li>
                        <li>Faculty Member</li>
                        <li>Student</li>
                        <li>Guardian
                        	<ul>
                            	<li>Students attendence</li>
                                <li>Progress report</li>
                                <li>Payment report</li>
                                <li>Class shedule</li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Careers</h4></li>
                        <li>Job Circular</li>
                        <li>Apply</li>
                        <li>Our Ergonomics</li>
                        <li>Ergonomics Environment</li>
                    </ul>
                </div>
                	
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Sports & Culture</h4></li>
                    	<li>Club</li>
                        <li>Events</li>
                        <li>Society</li>
                        <li>Culture</li>
                    </ul>

                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>University Accounts</h4></li>
                        <li>Financial Accounts</li>
                        <li>Financial Report</li>
                        <li>Petty cash</li>
                        <li>Cash Account</li>
                        <li>Student Fees</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>














