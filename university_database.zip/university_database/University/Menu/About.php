<!DOCTYPE html>
<html ng-app="exampleApp">
<head>
 <title>About</title>
	<script src="js/angular.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet"/>
</head>
<body>
<div class="container-fluid">
	<div class="row">
    	<div class="col-sm-12">
        	<div class="row">
            	<div class="col-sm-2">
                	<ul>
                    	<li><h4>Student Managemtn</h4></li>
                        <li>Attendece Count</li>
                        <li>Study Plan</li>
                    </ul>
                </div>
                <div class="col-sm-2"></div>
                <div class="col-sm-2"></div>
                <div class="col-sm-2"></div>
                <div class="col-sm-2"></div>
                <div class="col-sm-2"></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>














