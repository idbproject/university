<!DOCTYPE html>
<html ng-app="exampleApp">
<head>
 <title>Know IDB</title>
	<script src="js/angular.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap-theme.css" rel="stylesheet" />
    <link href="css/icon.css" rel="stylesheet"/>
    <link href="css/style.css" rel="stylesheet"/>
    <link href="css/font-awesome.icon.min.css" rel="stylesheet"/>

</head>
<body>
<div class="container-fluid">
	<div class="row">
    	<div class="col-sm-12">
        	<div class="row menuBeg">
            	<div class="col-sm-2">
                	<ul>
                    	<li><h4>Communication</h4></li>
                        <li>Address</li>
                        <li>Contact</li>
                        <li>Chat</li>
                        <li>University Location</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Information</h4></li>
                        <li>History</li>
                        <li>Governance</li>
                        <li>University Officer</li>
                        <li>Faculty Member</li>
                        <li>Strategic Plan</li>
                        <li>Financing and funding</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Academic Review</h4></li>
                    	<li>Annual Review</li>
                        <li>Mejor success</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Educational Review</h4></li>
                        <li>Faculty</li>
                    	<li>Course Fee</li>
                        <li>Credit and fees</li>
                        <li>Course and Semister</li>
                        <li>Course and Syllabus</li>
                        <li>Subject</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>IDB Facility</h4></li>
                    	<li>International Community</li>
                        <li>Credit Transfer</li>
                        <li>Library</li>
                        <li>Schollarship</li>
                        <li>Welfare and counselling</li>
                        <li>Award</li>
                        <li>Hostel</li>
                        <li>International Community</li>
                    </ul>
                </div>
                <div class="col-sm-2">
                	<ul>
                    	<li><h4>Studing at IDB University</h4></li>
                        <li>Gradguate Admission</li>
                        <li>Master's Admission</li>
                        <li>MBA Admission</li>
                        <li>Phd</li>
                    </ul>
                </div>
            </div>
        </div>
        
    </div>
    <i class="fa fa-facebook-square" style="font-size:48px;color:red"></i>
</div>
</body>
</html>














