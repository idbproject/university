var app=angular.module('defaultApp',['ngRoute']);

app.config(function($routeProvider){
	$routeProvider
	.when('/',{
			templateUrl:'login.php'
		})
		.when('/dashboard',{
			resolve:{
				"check": function($location, $rootScope){
					if(!$rootScope.login){
						$location.path('/');
					}	
				}
			},
			templateUrl:'view/dashboard.php'
		})
		.when('/change-password',{
			resolve:{
				"check": function($location, $rootScope){
					if(!$rootScope.login){
						$location.path('/');
					}	
				}
			},
			templateUrl:'view/password.php'
		})
		.when('/logout',{
			resolve:{
				"check": function($location, $rootScope){
					$rootScope.login = false;
					$location.path('/');
				}
			},
			redirectTo:'/'
		})
		.otherwise({
			redirectTo:'/'
	
		});
});

app.controller('defaultCtrl', function($scope, $location, $rootScope){
$scope.checkLogin = function(){
	if($scope.mail=='admin' && $scope.pass=='123'){
		$rootScope.login = true;
		$location.path('view/dashboard');
		}
		else{
			alert ("Invalid");
		}
	}

});