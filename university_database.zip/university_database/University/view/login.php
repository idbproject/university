<h1>Login Form</h1>
<div ng-controller="defaultCtrl">
	<form action="/">
        <input type="text" ng-model="mail"/><br><br>
        <input type="password" ng-model="pass"/><br><br>
        <button type="button" ng-click="checkLogin()">Login</button>
	</form>
</div>
