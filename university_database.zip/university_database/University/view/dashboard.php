<a href="#/change-password">Login</a><br>
<a href="#/logout">Log out</a>
<h1>Welcome to my site</h1>